-- En este archivo va el SQL para crear las tablas y alimentarlas con datos iniciales si es necesario.

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

INSERT INTO users (name, email, password) VALUES ('Jefree Alexander perratiao','alexander@gmail.com','dhahcfdahdnua'), ('Luisa', 'luisa@gmail.com','hadvvhajdhgas');

